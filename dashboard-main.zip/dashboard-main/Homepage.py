import streamlit as st

st.set_page_config(
    page_title="StellAI_Dashboard"
    )


st.title("Welcome to our page!!")
st.markdown( body="Welcome to our page!! In Stell.AI ,We are revolutionizing the circular economy by utilizing cutting-edge technology in artificiell intelligens, neural networks, and vision systems in conjunction with robotics.Our state-of-the-art identification and sorting system is not only cost-efficient, but it also has the power to make a significant impact on the environment.StellAI was found in the year 2022 and our official website is https://www.stell.ai")
            