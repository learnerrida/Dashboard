import sys
try:
    import plotly.express as px
    from dash import Dash,html,dcc,callback
    import streamlit as st
    import gradio as gr
    import seaborn as sns
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    import pywedge as pw
    import os
    import plotly.figure_factory as ff
    import os
    import openai
    import pinecone
    from langchain.document_loaders import DirectoryLoader
    from langchain.document_loaders import TextLoader
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.embeddings.openai import OpenAIEmbeddings
    from langchain.vectorstores import Pinecone
    from langchain.llms import OpenAI
    from langchain.chains.question_answering import load_qa_chain
    from langchain.chat_models import ChatOpenAI
    import gradio as gr
    from tqdm.autonotebook import tqdm
    import getpass
    import pinecone
    import gradio as gr
    from PIL import Image
    import matplotlib.pyplot as plt
    import numpy as np


except ImportError:
    print("error")
    sys.exit()












file1 = r"pages/prompt.txt"
PINECONE_API_KEY = st.secrets["PINECONE_API_KEY"]
PINECONE_ENV = 'us-west1-gcp-free'
os.environ["OPENAI_API_KEY"] = st.secrets["OPENAI_API_KEY"]
loader = TextLoader(file1)
documents = loader.load()
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
docs = text_splitter.split_documents(documents)
embeddings = OpenAIEmbeddings()


query = "summarize the data in prompt.txt"

# initialize pinecone
pinecone.init(
    api_key=PINECONE_API_KEY,  # find at app.pinecone.io
    environment=PINECONE_ENV,  # next to api key in console
)

index_name = "langchain-demo"

docsearch = Pinecone.from_documents(docs,embeddings, index_name=index_name)
docs = docsearch.similarity_search(query)

print(docs[0].page_content)

index = pinecone.Index("langchain-demo")
vectorstore = Pinecone(index, embeddings.embed_query, "text")

vectorstore.add_texts("More text!")
retriever = docsearch.as_retriever(search_type="mmr")
matched_docs = retriever.get_relevant_documents(query)
for i, d in enumerate(matched_docs):
    print(f"\n## Document {i}\n")
    print(d.page_content)

found_docs = docsearch.max_marginal_relevance_search(query, k=1, fetch_k=10)
for i, doc in enumerate(found_docs):
    print(f"{i + 1}.", doc.page_content, "\n")
model_name = "text-davinci-003"
llm = OpenAI(model_name=model_name)
from langchain.chains.question_answering import load_qa_chain
def function_llm(query):
    query=query
    chain = load_qa_chain(llm, chain_type="stuff")
    docs = docsearch.similarity_search(query)
    output= chain({"input_documents": docs, "question": query},return_only_outputs=True)
    return output

st.title('StellAI FAQs')
prompt=st.text_input('Enter your query here')

if prompt:
    response=function_llm(query=prompt)
    st.write(response)
