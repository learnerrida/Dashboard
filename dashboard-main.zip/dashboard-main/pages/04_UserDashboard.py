import sys
try:
    import plotly.express as px
    from dash import Dash,html,dcc,callback
    import streamlit as st
    import gradio as gr
    import seaborn as sns
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd
    import pywedge as pw
    import os
    import plotly.figure_factory as ff
    import os
    import openai
    import pinecone
    from langchain.document_loaders import DirectoryLoader
    from langchain.document_loaders import TextLoader
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.embeddings.openai import OpenAIEmbeddings
    from langchain.vectorstores import Pinecone
    from langchain.llms import OpenAI
    from langchain.chains.question_answering import load_qa_chain
    from langchain.chat_models import ChatOpenAI
    import gradio as gr
    from tqdm.autonotebook import tqdm
    import getpass
    import pinecone
    import gradio as gr
    from PIL import Image
    import matplotlib.pyplot as plt
    import numpy as np


except ImportError:
    print("error")
    sys.exit()

st.set_page_config(page_title="StellAI Dashboard",
                   page_icon=":bar_chart:",
                   layout="wide")


st.markdown("<h1 style='text-align: center; color: black;'>User Dashboard!!!</h1>", unsafe_allow_html=True)
st.caption('_Welcome to our page!! In Stell.AI ,We are revolutionizing the circular economy by utilizing cutting-edge technology in artificial intelligence, neural networks, and vision systems in conjunction with robotics_ ')
st.caption(' _Our state-of-the-art identification and sorting system is not only cost-efficient, but it also has the power to make a significant impact on the environment_ ')

file=r"pages/output.xlsx"
df=pd.read_excel(file)
st.dataframe(df)


months = ['January','February','March','April','May','June','July','August','September','October','November','December']
x = df['Class2']
y = df['ID']              
a = a = df['Area_in_m']
#b = df['Confidence score']
c= df['Class2']
#m= pd.Categorical(df['Month_Evaluated'],categories=months,ordered=True)
#year=df['year']
co2=df['co2Emission_perkg']
df_selection=df

st.markdown("<h1 style='text-align: center; color: black;'>Graphs</h1>", unsafe_allow_html=True)

        #left_column,right_column =st.columns(2)
        #with left_column:
        #st.subheader("Number of picked Materials")
        #with right_column:
        #st.subheader("proportions of picked material")
        
leftcolumn,rightcolumn = st.columns(2)

fig=plt.figure(figsize=(7,7))
        #px.histogram(data_frame=df_selection,y=df_selection['ID'],template="seaborn")
sns.histplot(
    data=df_selection,
    y=df_selection['ID'],
    #hue=df['Month_Evaluated'],
     multiple="stack",
    color='violet'
        ) 


plt.title("Number of picked Materials")
f= fig.savefig("Histogram-Number of picked Materials")
leftcolumn.pyplot(fig,use_container_width=True)

fig1=plt.figure(figsize=(7,7))
#fig1=plt.figure().set_figwidth(12)
data = df_selection['ID'].value_counts()
labels = ['pp','pp-5']
explode = [0, 0.1]
palette_color = sns.color_palette('pink')
plt.pie(data,colors=palette_color,explode=explode,
    autopct='%.0f%%',labels=labels)
plt.title("Proportions of Picked Material")
g= fig1.savefig("Pie Chart of Materials")

rightcolumn.pyplot(fig1,use_container_width=True)
        
cl1,cl2 = st.columns(2)
with cl1:
    with open("Histogram-Number of picked Materials.png", "rb") as file:
        btn= st.download_button(
        label="Download image",
        data=file,
        file_name="Hist.png",
        mime="image/png"
      )
                
with cl2:
    with open("Pie Chart of Materials.png", "rb") as file:
        btn= st.download_button(
        label="Download image",
         data=file,
        file_name="piechart.png",
        mime="image/png"
        )        

fig2= plt.figure(figsize=(15,5))
plt.title("CO2 Emission per Month")
palette = sns.color_palette("rocket_r")
my_plot= sns.lineplot(x=df_selection['Month_Evaluated'],y=co2,palette=['orange','blue'])
my_plot.set_xticklabels(my_plot.get_xticklabels(), rotation=45)
h= fig2.savefig("CO2Emission")
st.pyplot(fig2,use_container_width=True)
        
with open("CO2Emission.png", "rb") as file:
        btn= st.download_button(
        label="Download image",
        data=file,
        file_name="co2emissionchart.png",
        mime="image/png"
      )        

col1,col2 =st.columns(2)

fig3=plt.figure(figsize=(9,7))


newdf = df_selection.filter(items = ["year","ID"])
year2021_pp=df_selection[(df_selection['year']==2021) & (df_selection['ID']=='PP')].count()
year2021_pp5=df_selection[(df_selection['year']==2021) & (df_selection['ID']=='PP-5')].count()
year2022_pp5=df_selection[(df_selection['year']==2022) & (df_selection['ID']=='PP-5')].count()
year2022_pp=df_selection[(df_selection['year']==2022) & (df_selection['ID']=='PP')].count()

years_normal = [2021,2022]
ppvalue=[year2021_pp['ID'],year2022_pp['ID']]
pp5value=[year2021_pp5['ID'],year2022_pp5['ID']]

plt.bar(years_normal,ppvalue)
plt.bar(years_normal,pp5value)
plt.legend(['PP','PP-5'])
x_ticks=[2021,2022]
plt.xticks(ticks=x_ticks)
plt.xlabel("Year")
plt.ylabel("Count")
plt.title('Strip Plot as per Year')
i= fig3.savefig("stackplot_year")
col1.pyplot(fig3,use_container_width=True)




fig4=plt.figure(figsize=(9,7))
Month_count_Jan =df_selection[df_selection['Month_Evaluated']=='January']
jan_2021=Month_count_Jan[Month_count_Jan['year']==2021].count()
jan_2022=Month_count_Jan[Month_count_Jan['year']==2022].count()

Month_count_Feb =df_selection[df_selection['Month_Evaluated']=='February']
feb_2021=Month_count_Feb[Month_count_Feb['year']==2021].count()
feb_2022=Month_count_Feb[Month_count_Feb['year']==2022].count()

Month_count_Mar =df_selection[df_selection['Month_Evaluated']=='March']
Mar_2021=Month_count_Mar[Month_count_Mar['year']==2021].count()
Mar_2022=Month_count_Mar[Month_count_Mar['year']==2022].count()

Month_count_April =df_selection[df_selection['Month_Evaluated']=='April']
April_2021=Month_count_April[Month_count_April['year']==2021].count()
April_2022=Month_count_April[Month_count_April['year']==2022].count()

Month_count_May =df_selection[df_selection['Month_Evaluated']=='May']
May_2021=Month_count_May[Month_count_May['year']==2021].count()
May_2022=Month_count_May[Month_count_May['year']==2022].count()

Month_count_June =df_selection[df_selection['Month_Evaluated']=='June']
June_2021=Month_count_June[Month_count_June['year']==2021].count()
June_2022=Month_count_June[Month_count_June['year']==2022].count()

Month_count_July =df_selection[df_selection['Month_Evaluated']=='July']
July_2021=Month_count_July[Month_count_July['year']==2021].count()
July_2022=Month_count_July[Month_count_July['year']==2022].count()

Month_count_Aug =df_selection[df_selection['Month_Evaluated']=='August']
Aug_2021=Month_count_Aug[Month_count_Aug['year']==2021].count()
Aug_2022=Month_count_Aug[Month_count_Aug['year']==2022].count()

Month_count_Sep =df_selection[df_selection['Month_Evaluated']=='September']
Sep_2021=Month_count_Sep[Month_count_Sep['year']==2021].count()
Sep_2022=Month_count_Sep[Month_count_Sep['year']==2022].count()

Month_count_Oct =df_selection[df_selection['Month_Evaluated']=='October']
Oct_2021=Month_count_Oct[Month_count_Oct['year']==2021].count()
Oct_2022=Month_count_Oct[Month_count_Oct['year']==2022].count()

Month_count_Nov =df_selection[df_selection['Month_Evaluated']=='November']
Nov_2021=Month_count_Nov[Month_count_Nov['year']==2021].count()
Nov_2022=Month_count_Nov[Month_count_Nov['year']==2022].count()

Month_count_Dec =df_selection[df_selection['Month_Evaluated']=='December']
Dec_2021=Month_count_Dec[Month_count_Dec['year']==2021].count()
Dec_2022=Month_count_Dec[Month_count_Dec['year']==2022].count()
            

            

January2021=jan_2021.year
January2022=jan_2022.year
February2021=feb_2021.year
February2022=feb_2022.year
March2021=Mar_2021.year
March2022=Mar_2022.year
April2021=April_2021.year
April2022=April_2022.year
May2021=May_2021.year
May2022=May_2022.year
June2021=June_2021.year
June2022=June_2022.year
July2021=July_2021.year
July2022=July_2022.year
August2021=Aug_2021.year
August2022=Aug_2022.year
September2021=Sep_2021.year
September2022=Sep_2022.year
October2021=Oct_2021.year
October2022=Oct_2022.year
November2021=Nov_2021.year
November2022=Nov_2022.year
December2021=Dec_2021.year
December2022=Dec_2022.year
months=['January','February','March','April','May','June','July','August','September','October','November','December']
twentyone=[January2021,February2021,March2021,April2021,May2021,June2021,July2021,August2021,September2021,October2021,November2021,December2021]
twentytwo=[January2022,February2022,March2022,April2022,May2022,June2022,July2022,August2022,September2022,October2022,November2022,December2022]
palette = sns.color_palette("rocket_r")
plt.bar(months,twentyone,color='y')
plt.bar(months,twentytwo,bottom=twentyone,color='g')
plt.xticks(rotation=45)
plt.xlabel('Month')
plt.ylabel('Count')
plt.title('Strip Plot as per Month')
j= fig4.savefig("stackplot_Months")
col2.pyplot(fig4,use_container_width=True)


column1,ccolumn2 = st.columns(2)
with column1:
    with open("stackplot_year.png", "rb") as file:
        btn= st.download_button(
        label="Download image",
        data=file,
        file_name="Stackplot_months.png",
        mime="image/png"
        )
                
with ccolumn2:
    with open("stackplot_year.png", "rb") as file:
        btn= st.download_button(
        label="Download image",
        data=file,
        file_name="stackplot_year.png",
        mime="image/png"
        )        
   
